// ローカル起動用の設定ファイルです。
// Googleログインとクラウド同期を使う場合は、Firebase Consoleの値に置き換えてください。
export const FIREBASE_CONFIG = {
  apiKey: 'your-api-key',
  authDomain: 'your-project-id.firebaseapp.com',
  databaseURL: 'https://your-project-id-default-rtdb.asia-southeast1.firebasedatabase.app',
  projectId: 'your-project-id',
  appId: 'your-app-id'
};

export const TEAM_ID = 'arasaki-shipyard';
